package com.nsbm.model;

public class Participant {
    private int id;
    private String name;
    private String email;
    private String event;

    // Default constructor
    public Participant() {
    }

    // Constructor without id (for inserting new records)
    public Participant(String name, String email, String event) {
        this.name = name;
        this.email = email;
        this.event = event;
    }

    // Constructor with id (for fetching records)
    public Participant(int id, String name, String email, String event) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.event = event;
    }

    // Getters and setters
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getEvent() {
        return event;
    }
    public void setEvent(String event) {
        this.event = event;
    }
}
