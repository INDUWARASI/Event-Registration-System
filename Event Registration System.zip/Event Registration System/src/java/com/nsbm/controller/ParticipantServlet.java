package com.nsbm.controller;

import com.nsbm.dao.ParticipantDAO;
import com.nsbm.model.Participant;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/ParticipantServlet")
public class ParticipantServlet extends HttpServlet {
    private ParticipantDAO participantDAO;

    public void init() {
        participantDAO = new ParticipantDAO();
    }

    // Handle form submissions
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        registerParticipant(request, response);
    }

    // Display participant list
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        listParticipants(request, response);
    }

    // Method to register a new participant
    private void registerParticipant(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String event = request.getParameter("event");

        Participant newParticipant = new Participant(name, email, event);
        participantDAO.insertParticipant(newParticipant);
        response.sendRedirect("ParticipantServlet");
    }

    // Method to list all participants and forward to the JSP view
    private void listParticipants(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Participant> participantList = participantDAO.listParticipants();
        request.setAttribute("participantList", participantList);
        RequestDispatcher dispatcher = request.getRequestDispatcher("participantList.jsp");
        dispatcher.forward(request, response);
    }
}
